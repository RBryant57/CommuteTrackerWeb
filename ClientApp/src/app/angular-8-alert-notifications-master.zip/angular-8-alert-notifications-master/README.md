# angular-8-alert-notifications

Angular 8 - Alert (Toaster) Notifications

For a demo and further details see https://jasonwatmore.com/post/2019/07/05/angular-8-alert-toaster-notifications