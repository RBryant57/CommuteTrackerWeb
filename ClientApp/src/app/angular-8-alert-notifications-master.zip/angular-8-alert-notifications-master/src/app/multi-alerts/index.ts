﻿export * from './multi-alerts.component';
